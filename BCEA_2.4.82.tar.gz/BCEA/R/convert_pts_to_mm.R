
#' Use from Base  R to ggplot
#' 
#' @param x points
#' @keywords internal
#' 
convert_pts_to_mm <- function(x)
  x*72.27/25.4

