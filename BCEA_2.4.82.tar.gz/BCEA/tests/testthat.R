library(testthat)
library(BCEA)

test_check("BCEA")
