library(testthat)
library(multinma)

test_check("multinma")
